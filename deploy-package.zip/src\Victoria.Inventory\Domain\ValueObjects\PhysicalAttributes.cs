using System.Collections.Generic;
using Victoria.Core;

namespace Victoria.Inventory.Domain.ValueObjects
{
    public class PhysicalAttributes : ValueObject
    {
        public double Weight { get; }
        public double Length { get; }
        public double Width { get; }
        public double Height { get; }

        private PhysicalAttributes(double weight, double length, double width, double height)
        {
            Weight = weight;
            Length = length;
            Width = width;
            Height = height;
        }

        public static PhysicalAttributes Create(double weight, double length, double width, double height)
            => new PhysicalAttributes(weight, length, width, height);

        public static PhysicalAttributes Empty() => new PhysicalAttributes(0, 0, 0, 0);

        protected override IEnumerable<object> GetEqualityComponents()
        {
            yield return Weight;
            yield return Length;
            yield return Width;
            yield return Height;
        }
    }
}
