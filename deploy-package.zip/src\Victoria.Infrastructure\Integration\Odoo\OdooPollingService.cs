using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.DependencyInjection;
using Victoria.Core.Messaging;

namespace Victoria.Infrastructure.Integration.Odoo
{
    public class OdooPollingService : BackgroundService
    {
        private readonly ILogger<OdooPollingService> _logger;
        private readonly IServiceProvider _serviceProvider;
        private DateTime _lastSync = DateTime.UtcNow.AddDays(-1);

        public OdooPollingService(
            ILogger<OdooPollingService> logger, 
            IServiceProvider serviceProvider)
        {
            _logger = logger;
            _serviceProvider = serviceProvider;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            Console.WriteLine("[WORKER] Odoo Polling Service starting...");
            _logger.LogInformation("Odoo Polling Service is starting (Single-Tenant Mode).");

            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    Console.WriteLine("[WORKER] Creating Scope...");
                    using (var scope = _serviceProvider.CreateScope())
                    {
                        var odooClient = scope.ServiceProvider.GetRequiredService<IOdooRpcClient>();
                        var productSync = scope.ServiceProvider.GetRequiredService<ProductSyncService>();
                        var orderSync = scope.ServiceProvider.GetRequiredService<InboundOrderSyncService>();

                        Console.WriteLine($"[WORKER] Starting Sync Cycle (Last: {_lastSync})...");
                        _logger.LogInformation("Polling Odoo for changes since {LastSync}", _lastSync);

                        await SyncProducts(odooClient, productSync);
                        await SyncOrders(odooClient, orderSync);

                        _lastSync = DateTime.UtcNow;
                        Console.WriteLine("[WORKER] Sync Cycle Completed.");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[WORKER ERROR] {ex.Message}");
                    _logger.LogError(ex, "Error occurred during Odoo polling.");
                }

                await Task.Delay(TimeSpan.FromSeconds(60), stoppingToken);
            }
        }

        private async Task SyncProducts(IOdooRpcClient odooClient, ProductSyncService productSync)
        {
            _logger.LogInformation("[POLLING] Syncing Products...");
            
            var domain = new object[][] { 
                new object[] { "active", "=", true }
            };

            var fields = new string[] { 
                "id", "display_name", "default_code", "weight", 
                "image_128"
            };

            var products = await odooClient.SearchAndReadAsync<OdooProductDto>("product.product", domain, fields);
            _logger.LogInformation("[POLLING] Odoo returned {Count} products", products.Count);
            
            foreach (var p in products)
            {
                await productSync.SyncProduct(p);
            }
        }

        private async Task SyncOrders(IOdooRpcClient odooClient, InboundOrderSyncService orderSync)
        {
            _logger.LogInformation("[POLLING] Syncing pickings...");

            var domain = new object[][] { 
                new object[] { "state", "in", new string[] { "assigned", "confirmed", "waiting" } },
                new object[] { "picking_type_code", "in", new string[] { "incoming", "outgoing" } }
            };

            var fields = new string[] { "name", "picking_type_code", "id" };
            var pickings = await odooClient.SearchAndReadAsync<OdooOrderDto>("stock.picking", domain, fields);
            _logger.LogInformation("[POLLING] Odoo returned {Count} pickings", pickings.Count);
            
            foreach (var pick in pickings)
            {
                var moveDomain = new object[][] { new object[] { "picking_id", "=", pick.Id } };
                var moveFields = new string[] { "product_id", "product_uom_qty" };
                
                try {
                    var moves = await odooClient.SearchAndReadAsync<OdooOrderLineDto>("stock.move", moveDomain, moveFields);
                    pick.Lines = moves;
                    _logger.LogInformation("[POLLING] Handled picking {Ref} with {Count} lines", pick.Name, moves.Count);
                } catch (Exception ex) {
                    _logger.LogError(ex, "Error fetching lines for picking {Ref}", pick.Name);
                }

                await orderSync.SyncPicking(pick, pick.Picking_Type_Code);
            }
        }
    }
}
