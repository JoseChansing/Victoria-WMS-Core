package com.example.victoria_mobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
