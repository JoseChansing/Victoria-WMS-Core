using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Marten;
using Victoria.Inventory.Domain.Aggregates;
using Victoria.Inventory.Domain.ValueObjects;
using Victoria.Inventory.Application.Commands;

namespace Victoria.API.Controllers
{
    [ApiController]
    [Route("api/v1/inbound")]
    public class InboundController : ControllerBase
    {
        private readonly IDocumentSession _session;
        private readonly ReceiveLpnHandler _handler;

        public InboundController(IDocumentSession session, ReceiveLpnHandler handler)
        {
            _session = session;
            _handler = handler;
        }

        [HttpGet("kpis")]
        public async Task<IActionResult> GetKPIs()
        {
            var orders = await _session.Query<InboundOrder>()
                .Where(x => x.Status == "Pending")
                .ToListAsync();

            return Ok(new
            {
                PendingOrders = orders.Count,
                UnitsToReceive = orders.Sum(o => o.TotalUnits),
                HighPriorityCount = 0 // Mock por ahora
            });
        }

        [HttpGet("orders")]
        public async Task<IActionResult> GetOrders()
        {
            var orders = await _session.Query<InboundOrder>()
                .OrderByDescending(x => x.Date)
                .ToListAsync();

            // Enrich with product dimensions for UI calculations
            var skus = orders.SelectMany(o => o.Lines).Select(l => l.Sku).Distinct().ToList();
            var products = await _session.Query<Product>().Where(p => p.Sku.In(skus)).ToListAsync();
            var productDict = products.ToDictionary(p => p.Sku);

            var result = orders.Select(o => new {
                o.Id,
                o.OrderNumber,
                o.Supplier,
                o.Status,
                o.Date,
                o.TotalUnits,
                Lines = o.Lines.Select(l => new {
                    l.Sku,
                    l.ProductName,
                    l.ExpectedQty,
                    l.ReceivedQty,
                    Dimensions = productDict.TryGetValue(l.Sku, out var p) ? new {
                        Weight = p.PhysicalAttributes?.Weight ?? 0,
                        Length = p.PhysicalAttributes?.Length ?? 0,
                        Width = p.PhysicalAttributes?.Width ?? 0,
                        Height = p.PhysicalAttributes?.Height ?? 0
                    } : null
                })
            });

            return Ok(result);
        }

        [HttpPost("receive")]
        public async Task<IActionResult> Receive([FromBody] ReceiveRequest request)
        {
            var order = await _session.LoadAsync<InboundOrder>(request.OrderId);
            if (order == null) return NotFound("Order not found");

            // Build Command for the Handler
            var command = new ReceiveLpnCommand
            {
                OrderId = request.OrderId,
                LpnId = request.LpnId,
                RawScan = request.RawScan,
                Sku = request.Sku,
                ReceivedQuantity = request.Quantity,
                ExpectedQuantity = request.ExpectedQuantity > 0 ? request.ExpectedQuantity : request.Quantity,
                LpnCount = request.LpnCount,
                UnitsPerLpn = request.UnitsPerLpn,
                UserId = "System", // TODO: Get from Auth
                StationId = "STATION-01" // TODO: Get from station context
            };

            // Execute logic via Handler
            var generatedIds = await _handler.Handle(command);

            // 3. Update Order Line
            var skuToUpdate = request.Sku ?? request.RawScan;
            var line = order.Lines.FirstOrDefault(l => l.Sku == skuToUpdate);
            if (line != null)
            {
                line.ReceivedQty += request.Quantity;
                _session.Store(order);
                await _session.SaveChangesAsync();
            }

            return Ok(new { LpnIds = generatedIds, Count = generatedIds.Count });
        }
    }

    public class ReceiveRequest
    {
        public string OrderId { get; set; } = string.Empty;
        public string? Sku { get; set; }
        public string? LpnId { get; set; }
        public string? RawScan { get; set; }
        public int Quantity { get; set; }
        public int ExpectedQuantity { get; set; }
        public int LpnCount { get; set; } = 1;
        public int UnitsPerLpn { get; set; }
    }
}
