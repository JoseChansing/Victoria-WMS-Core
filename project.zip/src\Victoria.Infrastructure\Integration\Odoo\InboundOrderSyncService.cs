using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Victoria.Inventory.Domain.Aggregates;

namespace Victoria.Infrastructure.Integration.Odoo
{
    public class OdooOrderLineDto
    {
        public string Product_Id { get; set; } = string.Empty;
        public int Product_Uom_Qty { get; set; }
    }

    public class OdooOrderDto
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty; // OrderNumber
        public int Company_Id { get; set; }
        public string Picking_Type_Code { get; set; } = string.Empty;
        public List<OdooOrderLineDto> Lines { get; set; } = new();
    }

    public class InboundOrderSyncService
    {
        private readonly ILogger<InboundOrderSyncService> _logger;
        private static readonly Dictionary<int, string> TenantMapping = new()
        {
            { 1, "PERFECTPTY" }, { 2, "NATSUKI" }, { 3, "PDM" }, { 4, "FILTROS" }
        };

        public InboundOrderSyncService(ILogger<InboundOrderSyncService> logger)
        {
            _logger = logger;
        }

        public async Task SyncPicking(OdooOrderDto odooPicking, string type)
        {
            if (!TenantMapping.TryGetValue(odooPicking.Company_Id, out var tenantId))
                return;

            _logger?.LogInformation("[OdooSync] Processing {Type} Picking: {Ref}", type, odooPicking.Name);

            // ACL: Normalización de OrderNumber (Nivelación Odoo -> Victoria)
            var cleanLines = (odooPicking.Lines ?? new())
                .GroupBy(l => l.Product_Id)
                .Select(g => new { Sku = g.Key, Qty = g.Sum(x => x.Product_Uom_Qty) });

            if (type == "incoming")
            {
                // Mapear Incoming a InboundOrder
                Console.WriteLine($"[ReceiptSync] Imported Picking '{odooPicking.Name}' as InboundOrder for {tenantId}");
            }
            else
            {
                // Mapear Outgoing a OutboundOrder
                Console.WriteLine($"[PickSync] Imported Picking '{odooPicking.Name}' as OutboundOrder for {tenantId}");
            }

            await Task.CompletedTask;
        }
    }
}
