using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Victoria.Infrastructure.Integration.Odoo
{
    // DTO Sucio de Odoo
    public class OdooProductDto
    {
        public int Id { get; set; }
        public int Company_Id { get; set; }
        public string Display_Name { get; set; } = string.Empty;
        public string Default_Code { get; set; } = string.Empty;
        public double Weight { get; set; }
        public string? Image_1920 { get; set; } // image_1920 (Base64)
        public string? Image_Template { get; set; } // placeholder for template
        public string? Brand_Logo { get; set; }
        public string? Image_128 { get; set; } // thumbnail
    }

    public class ProductSyncService
    {
        private static readonly Dictionary<int, string> TenantMapping = new()
        {
            { 1, "PERFECTPTY" },
            { 2, "NATSUKI" },
            { 3, "PDM" },
            { 4, "FILTROS" }
        };

        public async Task SyncProduct(OdooProductDto odooProduct)
        {
            if (!TenantMapping.TryGetValue(odooProduct.Company_Id, out var tenantId))
                return;

            string skuCode = (odooProduct.Default_Code ?? "").ToUpper().Trim();
            
            // LÓGICA DE IMAGEN (CASCADA)
            string imageSource = "null";
            if (!string.IsNullOrEmpty(odooProduct.Image_1920)) imageSource = "variant";
            else if (!string.IsNullOrEmpty(odooProduct.Image_128)) imageSource = "thumbnail";

            Console.WriteLine($"[ProductSync] Upserted SKU '{skuCode}' | Source: {imageSource}");
            
            // Simulación de interacción con DB Victoria
            // var sku = new Sku(tenantId, skuCode, odooProduct.Name);
            // sku.SetImageMetadata(imageSource, odooProduct.Thumbnail); 
            
            await Task.CompletedTask;
        }
    }
}
